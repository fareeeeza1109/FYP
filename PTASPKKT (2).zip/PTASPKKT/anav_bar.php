<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>
 
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
          <ul class="glyphicon glyphicon navbar-right" style="float: right;">
<style>
  h4 {
       float: right;
      }
</style>

      <h4 style="color: #000000"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Admin: <?php if (isset($_SESSION['namaguru'])): ?> <?php echo $_SESSION['namaguru']; ?>
      

    </p>
    <p>

    <?php endif ?></h4>
    </ul>

      <li><a href="amainpage.php">Halaman Utama</a></li>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Laporan<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adaftarguru.php">Senarai Laporan</a></li>
            <li><a href="asenaraiguru.php">Laporan Kedatangan</a></li>
          </ul>
        </li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Kedatangan<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="arekodkedatangan.php">Rekod Kedatangan</a></li>
          </ul>
        </li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pelajar<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adaftarpelajar.php">Daftar Pelajar</a></li>
            <li><a href="asenaraipelajar.php">Senarai Pelajar</a></li>
          </ul>
        </li>
      </ul>

       <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Guru<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adaftarguru.php">Daftar Guru</a></li>
            <li><a href="asenaraiguru.php">SenaraiGuru</a></li>
          </ul>
        </li>
      </ul>

       
         

      </ul>


      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="logout.php">Log Keluar</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>