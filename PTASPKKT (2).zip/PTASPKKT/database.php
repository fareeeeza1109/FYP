<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a175456";
$password = "cuteorangefox";
$dbname = "a175456";

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
?>