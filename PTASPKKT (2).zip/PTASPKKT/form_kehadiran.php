<?php
  include_once 'form_kehadiran_crud.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : Kehadiran Pelajar</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
    body{
        background-image: url(bg.jpg);
      }

  .header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}

    </style>
</head>

<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  
<body>

  <h3 style="text-align: center; font-weight: bold;">Log Masuk Kehadiran Kelas dalam Talian</h3>

  <br>

  <p style="text-align: center;">*Sila masukkan butir di bawah dengan menggunakan ID Pelajar yang telah dibekalkan oleh pihak sekolah.</p>


  <div class="container-fluid">
  <div class="row" style="height: 200px; text-align: center;">
    <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
      <div class="page-header">
        <h2>Kehadiran Pelajar</h2>
      </div>


<!--search-->
  <div class="container-fluid">
  
        <h2></h2>
      </div>
    <table>
    <form method="post">
      <tr>
      </tr>
      <tr>
       <td><input id="keyword" name="keyword" class="form-control" type="text" placeholder="ID Pelajar" style="width: 250px;" required></td>

 <td><input type="submit" name="search" value="Search" style="width: 100px; background-color: lightgreen; "></td>
</tr>
</form>
    </table>
    </div>
  </div>

  <br>

  
  <!--id pelajar-->
    <form action="adaftarpelajar.php" method="post" class="form-horizontal" enctype="multipart/form-data">

      <div class="form-group">
          <label for="idp" class="col-sm-3 control-label">ID</label>
          <div class="col-sm-6">
       <input name="pid" type="text" class="form-control" id="idpelajar" placeholder="ID Pelajar" value="<?php if(isset($_GET['edit'])) echo $editrow['id_pelajar']; ?>" required>

       </div>
        </div>

        <!--nama pelajar-->
       <div class="form-group">
          <label for="np" class="col-sm-3 control-label">Nama Penuh</label>
          <div class="col-sm-6">
       <input name="namapelajar" type="text" class="form-control" id="namapelajar" placeholder="Nama Penuh" value="<?php if(isset($_GET['edit'])) echo $editrow['nama_pelajar']; ?>" required>
      </div>
        </div>


        <!--tingkatan pelajar -->
      <div class="form-group">
          <label for="tingpel" class="col-sm-3 control-label">Tingkatan</label>
          <div class="col-sm-6">

      <select name="tingkatanpelajar" class="form-control" id="tingpel" required>
        <option value="">Sila Pilih</option>
        <option value="1" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="1") echo "selected"; ?>>1</option>
            <option value="2" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="2") echo "selected"; ?>>2</option>
            <option value="3" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="3") echo "selected"; ?>>3</option>
            <option value="4" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="4") echo "selected"; ?>>4</option>
            <option value="5" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="5") echo "selected"; ?>>5</option>
      </select> 
      </div>
        </div>
 
        <!--kelas pelajar-->
      <div class="form-group">
          <label for="kelaspel" class="col-sm-3 control-label">Kelas</label>
          <div class="col-sm-6">

      <select name="kelaspelajar" class="form-control" id="kelpel" required>
        <option value="">Sila Pilih</option>
        <option value="Adil" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Adil") echo "selected"; ?>>Adil</option>
            <option value="Bestari" <?php if(isset($_GET['
            edit'])) if($editrow['kelas_pelajar']=="Bestari") echo "selected"; ?>>Bestari</option>
            <option value="Cekal" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Cekal") echo "selected"; ?>>Cekal</option>
            <option value="Dinamik" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Dinamik") echo "selected"; ?>>Dinamik</option>
            <option value="Efisyen" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Efisyen") echo "selected"; ?>>Efisyen</option>
            <option value="Fikir" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Fikir") echo "selected"; ?>>Fikir</option>
            <option value="Gigih" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Gigih") echo "selected"; ?>>Gigih</option>
            <option value="Harmoni" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Harmoni") echo "selected"; ?>>Harmoni</option>
            <option value="Ikhlas" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Ikhlas") echo "selected"; ?>>Ikhlas</option>
            <option value="Jujur" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Jujur") echo "selected"; ?>>Jujur</option>
            <option value="Kreatif" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Kreatif") echo "selected"; ?>>Kreatif</option>
            <option value="Lestari" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Lestari") echo "selected"; ?>>Lestari</option>
            <option value="Maju" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Maju") echo "selected"; ?>>Maju</option>
            <option value="Nurani" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Nurani") echo "selected"; ?>>Nurani</option>
      </select> 
      </div>
        </div>


      <!--subjek terkini-->
      <div class="form-group">
          <label for="subjpel" class="col-sm-3 control-label">Subjek Terkini</label>
          <div class="col-sm-6">

      <select name="subjekpelajar" class="form-control" id="subguru1" required>
        <option value="">Sila Pilih</option>
        <option value="Bahasa Melayu" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Bahasa Melayu") echo "selected"; ?>>Bahasa Melayu</option>
            <option value="Bahasa Inggeris" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Bahasa Inggeris") echo "selected"; ?>>Bahasa Inggeris</option>
            <option value="Sejarah" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Sejarah") echo "selected"; ?>>Sejarah</option>
            <option value="Geografi" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Geografi") echo "selected"; ?>>Geografi</option>
            <option value="Sains" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Sains") echo "selected"; ?>>Sains</option>
            <option value="Pendidikan Islam" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Pendidikan Islam") echo "selected"; ?>>Pendidikan Islam</option>
            <option value="Kimia" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Kimia") echo "selected"; ?>>Kimia</option>
            <option value="Biologi" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Biologi") echo "selected"; ?>>Biologi</option>
            <option value="Matematik" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Matematik") echo "selected"; ?>>Matematik</option>
            <option value="Matematik Tambahan" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Matematik Tambahan") echo "selected"; ?>>Matematik Tambahan</option>
            <option value="Reka Bentuk Teknologi" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Reka Bentuk Teknologi") echo "selected"; ?>>Reka Bentuk Teknologi</option>
            <option value="Tasawwur Islam" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Tasawwur Islam") echo "selected"; ?>>Tasawwur Islam</option>
            <option value="Ekonomi Asas" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Ekonomi Asas") echo "selected"; ?>>Ekonomi Asas</option>
            <option value="Prinsip Perakaunan" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Prinsip Perakaunan") echo "selected"; ?>>Prinsip Perakaunan</option>
            <option value="Pendidikan Jasmani" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Pendidikan Jasmani") echo "selected"; ?>>Pendidikan Jasmani</option>
            <option value="Pendidikan Seni Visual" <?php if(isset($_GET['edit'])) if($editrow['subj_pelajar']=="Pendidikan Seni Visual") echo "selected"; ?>>Pendidikan Seni Visual</option>
      </select> 
      </div>
        </div>


        <!--nama guru ajar--> 
       <div class="form-group">
          <label for="ng" class="col-sm-3 control-label">Guru Subjek Terkini</label>
          <div class="col-sm-6">
       <input name="namaguru" type="text" class="form-control" id="nguru" placeholder="Nama Guru" value="<?php if(isset($_GET['edit'])) echo $editrow['nama_guru']; ?>" required>

       </div>
        </div>

 <br>

<!--function button-->

        <div class="form-group">
          <div class="col-sm-offset-3 col-sm-9">

      <?php if (isset($_GET['edit'])) { ?>
      <input type="hidden" name="oldpid" value="<?php echo $editrow['id_pelajar']; ?>">
      <button class="btn btn-default" type="submit" name="update"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Kemaskini</button>
      <?php } else { ?>
      <button class="btn btn-default" type="submit" name="create"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Hadir</button>
      <?php } ?>
      <button class="btn btn-default" type="reset"><span class="glyphicon glyphicon-erase" aria-hidden="true"></span> Reset</button>
      

       </div>
      </div>
    </form>
     </div>
  </div>

  <div class="row" style="margin-left: -30px;">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-7 col-md-offset-2">
      <div class="page-header">
        <h2>Pelajar Hadir</h2>
      </div>
      <table class="table table-striped table-bordered">
    
      <tr>
          <th>Nama</th>
          <th>Tingkatan</th>
          <th>Kelas</th>
          <th>Subjek Terkini</th>
          
      </tr>

      <?php
      // Read
      $per_page = 5; //record per page
      if (isset($_GET["page"]))
        $page = $_GET["page"];
      else
        $page = 1;
      $start_from = ($page-1) * $per_page;
      try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT * FROM tbl_pelajarmasuk_fyp");
           $stmt = $conn->prepare("select * from tbl_pelajarmasuk_fyp LIMIT $start_from, $per_page");
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $readrow) {
      ?>   
      <tr>
        <td><?php echo $readrow['nama_pelajar']; ?></td>
        <td><?php echo $readrow['tingkatan_pelajar']; ?></td>
        <td><?php echo $readrow['kelas_pelajar']; ?></td>
        <td><?php echo $readrow['subj_pelajar']; ?></td>
      </tr>
      <?php
      }
      ?>
 
    </table>
    </div>
  </div>

  <!--pagination bootstraps-->
  <div class="row" style="margin-left: -30px;">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <nav>
          <ul class="pagination">
          <?php
          try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare("SELECT * FROM tbl_pelajarmasuk_fyp");
            $stmt->execute();
            $result = $stmt->fetchAll();
            $total_records = count($result);
          }
          catch(PDOException $e){
                echo "Error: " . $e->getMessage();
          }
          $total_pages = ceil($total_records / $per_page);
          ?>
          <?php if ($page==1) { ?>
            <li class="disabled"><span aria-hidden="true">«</span></li>
          <?php } else { ?>
            <li><a href="form_kehadiran.php?page=<?php echo $page-1 ?>" aria-label="Kembali"><span aria-hidden="true">«</span></a></li>
          <?php
          }
          for ($i=1; $i<=$total_pages; $i++)
            if ($i == $page)
              echo "<li class=\"active\"><a href=\"form_kehadiran.php?page=$i\">$i</a></li>";
            else
              echo "<li><a href=\"form_kehadiran.php?page=$i\">$i</a></li>";
          ?>
          <?php if ($page==$total_pages) { ?>
            <li class="disabled"><span aria-hidden="true">»</span></li>
          <?php } else { ?>
            <li><a href="form_kehadiran.php?page=<?php echo $page+1 ?>" aria-label="Previous"><span aria-hidden="true">»</span></a></li>
          <?php } ?>
        </ul>
      </nav>
    </div>

  </div>
</div>

   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>