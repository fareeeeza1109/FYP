<?php
  include_once 'database.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : MAKLUMAT PELAJAR</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
      body{
        background-image: url(bg.jpg);
      }

      .header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}

    </style>
</head>

<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  
<body>
  <!--navigation bar-->
  <?php include_once 'anav_bar.php'; ?>

    <?php
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM tbl_daftarpelajar_fyp WHERE id_pelajar = :pid");
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $pid = $_GET['pid'];
      $stmt->execute();
      $readrow = $stmt->fetch(PDO::FETCH_ASSOC);
      }
    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
    ?>

    <div class="container-fluid">
  <div class="row">
    
    </div>
    <div class="col-xs-12 col-sm-5 col-md-4">
      <div class="panel panel-default">
      <div class="panel-heading"><strong>MAKLUMAT PELAJAR</strong></div>
      <div class="panel-body">
          Berikut adalah maklumat pelajar yang telah daftar:
      </div>
      <table class="table">
        <tr>
          <td class="col-xs-4 col-sm-4 col-md-4"><strong>ID Pelajar</strong></td>
          <td><?php echo $readrow['id_pelajar'] ?></td>
        </tr>
        <tr>
          <td><strong>Kad Pengenalan</strong></td>
          <td><?php echo $readrow['ic_pelajar'] ?></td>
        </tr>
        <tr>
          <td><strong>Nama Penuh</strong></td>
          <td><?php echo $readrow['nama_pelajar'] ?></td>
        </tr>
        <tr>
          <td><strong>Tingkatan</strong></td>
          <td><?php echo $readrow['tingkatan_pelajar'] ?></td>
        </tr>
        <tr>
          <td><strong>Kelas</strong></td>
          <td><?php echo $readrow['kelas_pelajar'] ?></td>
        </tr>
        <tr>
          <td><strong>No. Telefon</strong></td>
          <td><?php echo $readrow['tel_pelajar'] ?></td>
        </tr>
        <tr>
          <td><strong>No. Telefon Kecemasan</strong></td>
          <td><?php echo $readrow['tel_ibubapa'] ?></td>
        </tr>
      </table>
      </div>
    </div>
  </div>
</div>
 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    
</body>
</html>