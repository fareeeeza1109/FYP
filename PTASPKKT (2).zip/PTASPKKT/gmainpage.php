<?php
include_once 'database.php';
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    
   <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
     <style type="text/css">
      
     body {
    background-image: url("bg.jpg");
  }

   .header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}
    </style>

</head>
<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  


<body>
  
    <?php include_once 'gnav_bar.php'; ?> 

     <br>

    <h1 style="text-align:center; font-weight: bold;">MISI</h1>

<p style="text-align:center">Menyediakan persekitaran terbaik yang mempersiapkan pelajar untuk berfungsi sebagai Usahawan, Pekerja, dan Warganegara di Dunia Globalisasi.</p>

<br>

<h1 style="text-align:center; font-weight: bold;">VISI</h1>

<p style="text-align:center">SMKSKI ialah mendidik modal insan menjadi cemerlang dalam semua aspek melalui aktiviti pembentukan sahsiah,kurikulum dan kokurikulum</p>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

</body>
</html>