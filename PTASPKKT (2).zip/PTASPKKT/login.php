<?php 
include_once 'database.php';


	
		$stmt = $conn->prepare("SELECT * FROM tbl_daftarguru_fyp WHERE id_guru = :gid AND password_guru = :pass AND position_guru = :pos");
		
		$stmt->bindParam(':gid', $gid, PDO::PARAM_STR);
		$stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
		$stmt->bindParam(':pos', $pos, PDO::PARAM_STR);

		$gid=$_POST['gid'];
		$pass=$_POST['pass'];
		$pos=$_POST['pos'];

	

		$stmt->execute();
		$result = $stmt->fetchAll();
		$bil_row = $stmt->rowCount();
		
			if($bil_row > 0)
			{
				session_start();
				
				$_SESSION['id_guru']=$gid;
 
				if ($_POST["pos"]=== "Admin") {
					# code...

					header("location:amainpage.php");
				}
				else 
				{

					# code...
					header("location:gmainpage.php");
				}
					
			}	
			else
			{

				header("location:loginpage.php?login=failed");

			}



?>