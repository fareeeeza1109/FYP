<?php
 
include_once 'database.php';
 
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//Create
if (isset($_POST['create'])) {
 
  try {
 
      $stmt = $conn->prepare("INSERT INTO tbl_daftarguru_fyp(id_guru,
        nama_guru, ic_guru, tel_guru, tingkatan_guru,
        kelas_guru1, kelas_guru2, subj_guru1, subj_guru2, password_guru, retype_pass_guru, position_guru) VALUES(:gid, :namaguru, :icguru, :telefonguru,
        :tingkatanguru, :kelasguru1, :kelas_guru2, :subjekguru1, :subj_guru2, :pass, :repassguru, :pos)");
     

      $stmt->bindParam(':gid', $gid, PDO::PARAM_STR);
      $stmt->bindParam(':namaguru', $namaguru, PDO::PARAM_STR);
      $stmt->bindParam(':icguru', $icguru, PDO::PARAM_STR);
      $stmt->bindParam(':telefonguru', $telefonguru, PDO::PARAM_INT);
      $stmt->bindParam(':tingkatanguru', $tingkatanguru, PDO::PARAM_INT);
      $stmt->bindParam(':kelasguru1', $kelasguru1, PDO::PARAM_STR);
      $stmt->bindParam(':kelasguru2', $kelasguru2, PDO::PARAM_STR);
      $stmt->bindParam(':subjekguru1', $subjekguru1, PDO::PARAM_STR);
      $stmt->bindParam(':subjekguru2', $subjekguru2, PDO::PARAM_STR);
      $stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
      $stmt->bindParam(':repassguru', $repassguru, PDO::PARAM_STR);
      $stmt->bindParam(':pos', $pos, PDO::PARAM_STR);
       
    $gid = $_POST['gid'];
    $namaguru = $_POST['namaguru'];
    $icguru = $_POST['icguru'];
    $telefonguru =  $_POST['telefonguru'];
    $tingkatanguru = $_POST['tingkatanguru'];
    $kelasguru1 = $_POST['kelasguru1'];
    $kelasguru2 = $_POST['kelasguru2'];
    $subjekguru1 = $_POST['subjekguru1'];
    $subjekguru2 = $_POST['subjekguru2'];
    $pass = $_POST['pass'];
    $repassguru = $_POST['repassguru'];
    $pos = $_POST['pos'];

     
    $stmt->execute();
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Update
if (isset($_POST['update'])) {
 
  try {
 
      $stmt = $conn->prepare("UPDATE tbl_daftarguru_fyp SET id_guru = :gid,
        nama_guru = :namaguru, ic_guru = :icguru, tel_guru = :telefonguru,
        tingkatan_guru = :tingkatanguru, kelas_guru1 = :kelasguru1, kelas_guru2 = :kelasguru2, subj_guru1 = :subjekguru1, subj_guru2 = :subjekguru2, password_guru = :pass, retype_pass_guru = :repassguru, position_guru = :pos
        WHERE id_guru = :oldgid");
     
      $stmt->bindParam(':gid', $gid, PDO::PARAM_STR);
      $stmt->bindParam(':namaguru', $namaguru, PDO::PARAM_STR);
      $stmt->bindParam(':icguru', $icguru, PDO::PARAM_STR);
      $stmt->bindParam(':telefonguru', $telefonguru, PDO::PARAM_INT);
      $stmt->bindParam(':tingkatanguru', $tingkatanguru, PDO::PARAM_INT);
      $stmt->bindParam(':kelasguru1', $kelasguru1, PDO::PARAM_STR);
      $stmt->bindParam(':kelasguru2', $kelasguru2, PDO::PARAM_STR);
      $stmt->bindParam(':subjekguru1', $subjekguru1, PDO::PARAM_STR);
      $stmt->bindParam(':subjekguru2', $subjekguru2, PDO::PARAM_STR);
       $stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
      $stmt->bindParam(':repassguru', $repassguru, PDO::PARAM_STR);
      $stmt->bindParam(':pos', $pos, PDO::PARAM_STR);
      $stmt->bindParam(':oldgid', $oldgid, PDO::PARAM_STR);
       
    $gid = $_POST['gid'];
    $namaguru = $_POST['namaguru'];
    $icguru = $_POST['icguru'];
    $telefonguru =  $_POST['telefonguru'];
    $tingkatanguru = $_POST['tingkatanguru'];
    $kelasguru1 = $_POST['kelasguru1'];
    $kelasguru2 = $_POST['kelasguru2'];
    $subjekguru1 = $_POST['subjekguru1'];
    $subjekguru2 = $_POST['subjekguru2'];
    $pass = $_POST['pass'];
    $repassguru = $_POST['repassguru'];
    $pos = $_POST['pos'];
    $oldgid = $_POST['oldgid'];
     
    $stmt->execute();
 
    header("Location: adaftarguru.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Delete
if (isset($_GET['delete'])) {
 
  try {
 
      $stmt = $conn->prepare("DELETE FROM tbl_daftarguru_fyp WHERE id_guru = :gid");
     
      $stmt->bindParam(':gid', $gid, PDO::PARAM_STR);
       
    $gid = $_GET['delete'];
     
    $stmt->execute();
 
    header("Location: adaftarguru.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Edit
if (isset($_GET['edit'])) {
 
  try {
 
      $stmt = $conn->prepare("SELECT * FROM tbl_daftarguru_fyp WHERE id_guru = :gid");
     
      $stmt->bindParam(':gid', $gid, PDO::PARAM_STR);
       
    $gid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
  $conn = null;
?>