<?php
  include_once 'adaftarpelajar_crud.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : Daftar Pelajar</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
    body{
        background-image: url(bg.jpg);
      }

  .header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}

    </style>
</head>

<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  
<body>
  <!--navigation bar-->
  <?php include_once 'anav_bar.php'; ?>

  <div class="container-fluid">
  <div class="row" style="height: 200px; margin-left: -100px;">
    <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
      <div class="page-header">
        <h2>Daftar Pelajar</h2>
      </div>
  
  <!--id pelajar-->
    <form action="adaftarpelajar.php" method="post" class="form-horizontal" enctype="multipart/form-data">

      <div class="form-group">
          <label for="idp" class="col-sm-3 control-label">ID</label>
          <div class="col-sm-6">
       <input name="pid" type="text" class="form-control" id="idpelajar" placeholder="ID Pelajar" value="<?php if(isset($_GET['edit'])) echo $editrow['id_pelajar']; ?>" required>

       </div>
        </div>

       <!--ic pelajar--> 
       <div class="form-group">
          <label for="icp" class="col-sm-3 control-label">Kad Pengenalan</label>
          <div class="col-sm-6">
       <input name="icpelajar" type="text" class="form-control" id="icpelajar" placeholder="Kad Pengenalan" value="<?php if(isset($_GET['edit'])) echo $editrow['ic_pelajar']; ?>" required>

       </div>
        </div>
      

       <!--nama pelajar-->
       <div class="form-group">
          <label for="np" class="col-sm-3 control-label">Nama Penuh</label>
          <div class="col-sm-6">
       <input name="namapelajar" type="text" class="form-control" id="namapelajar" placeholder="Kad Pengenalan" value="<?php if(isset($_GET['edit'])) echo $editrow['nama_pelajar']; ?>" required>
      </div>
        </div>


        <!--tingkatan pelajar -->
      <div class="form-group">
          <label for="tingpel" class="col-sm-3 control-label">Tingkatan</label>
          <div class="col-sm-6">

      <select name="tingkatanpelajar" class="form-control" id="tingpel" required>
        <option value="">Sila Pilih</option>
        <option value="1" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="1") echo "selected"; ?>>1</option>
            <option value="2" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="2") echo "selected"; ?>>2</option>
            <option value="3" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="3") echo "selected"; ?>>3</option>
            <option value="4" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="4") echo "selected"; ?>>4</option>
            <option value="5" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_pelajar']=="5") echo "selected"; ?>>5</option>
      </select> 
      </div>
        </div>
 
        <!--kelas pelajar-->
      <div class="form-group">
          <label for="kelaspel" class="col-sm-3 control-label">Kelas</label>
          <div class="col-sm-6">

      <select name="kelaspelajar" class="form-control" id="kelpel" required>
        <option value="">Sila Pilih</option>
        <option value="Adil" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Adil") echo "selected"; ?>>Adil</option>
            <option value="Bestari" <?php if(isset($_GET['
            edit'])) if($editrow['kelas_pelajar']=="Bestari") echo "selected"; ?>>Bestari</option>
            <option value="Cekal" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Cekal") echo "selected"; ?>>Cekal</option>
            <option value="Dinamik" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Dinamik") echo "selected"; ?>>Dinamik</option>
            <option value="Efisyen" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Efisyen") echo "selected"; ?>>Efisyen</option>
            <option value="Fikir" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Fikir") echo "selected"; ?>>Fikir</option>
            <option value="Gigih" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Gigih") echo "selected"; ?>>Gigih</option>
            <option value="Harmoni" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Harmoni") echo "selected"; ?>>Harmoni</option>
            <option value="Ikhlas" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Ikhlas") echo "selected"; ?>>Ikhlas</option>
            <option value="Jujur" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Jujur") echo "selected"; ?>>Jujur</option>
            <option value="Kreatif" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Kreatif") echo "selected"; ?>>Kreatif</option>
            <option value="Lestari" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Lestari") echo "selected"; ?>>Lestari</option>
            <option value="Maju" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Maju") echo "selected"; ?>>Maju</option>
            <option value="Nurani" <?php if(isset($_GET['edit'])) if($editrow['kelas_pelajar']=="Nurani") echo "selected"; ?>>Nurani</option>
      </select> 
      </div>
        </div>


       <!--telefon pelajar-->
      <div class="form-group">
          <label for="telpel" class="col-sm-3 control-label">No. Telefon</label>
          <div class="col-sm-6">
      <input name="telefonpelajar" type="text" class="form-control" id="telpel" placeholder="No. Telefon" value="<?php if(isset($_GET['edit'])) echo $editrow['tel_pelajar']; ?>"required>
      </div>
        </div>


        <!--telefon ibubapa-->
      <div class="form-group">
          <label for="telibubapa" class="col-sm-3 control-label">No. Tel Kecemasan</label>
          <div class="col-sm-6">
      <input name="telefonibubapa" type="text" class="form-control" id="telpel" placeholder="No. Telefon" value="<?php if(isset($_GET['edit'])) echo $editrow['tel_ibubapa']; ?>"required>
      </div>
        </div>
 <br><br>

<!--function button-->

        <div class="form-group">
          <div class="col-sm-offset-3 col-sm-9">

      <?php if (isset($_GET['edit'])) { ?>
      <input type="hidden" name="oldpid" value="<?php echo $editrow['id_pelajar']; ?>">
      <button class="btn btn-default" type="submit" name="update"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Kemaskini</button>
      <?php } else { ?>
      <button class="btn btn-default" type="submit" name="create"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Daftar</button>
      <?php } ?>
      <button class="btn btn-default" type="reset"><span class="glyphicon glyphicon-erase" aria-hidden="true"></span> Reset</button>
      

       </div>
      </div>
    </form>
     </div>
  </div>

  <div class="row" style="margin-left: -30px;">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-7 col-md-offset-2">
      <div class="page-header">
        <h2>Pelajar Berdaftar</h2>
      </div>
      <table class="table table-striped table-bordered">
    
      <tr>
          <th>ID Pelajar</th>
          <th>Kad Pengenalan</th>
          <th>Nama</th>
          <th>Tingkatan</th>
          <th>Kelas</th>
          <th></th>
      </tr>

      <?php
      // Read
      $per_page = 5; //record per page
      if (isset($_GET["page"]))
        $page = $_GET["page"];
      else
        $page = 1;
      $start_from = ($page-1) * $per_page;
      try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT * FROM tbl_daftarpelajar_fyp");
           $stmt = $conn->prepare("select * from tbl_daftarpelajar_fyp LIMIT $start_from, $per_page");
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $readrow) {
      ?>   
      <tr>
        <td><?php echo $readrow['id_pelajar']; ?></td>
        <td><?php echo $readrow['ic_pelajar']; ?></td>
        <td><?php echo $readrow['nama_pelajar']; ?></td>
        <td><?php echo $readrow['tingkatan_pelajar']; ?></td>
        <td><?php echo $readrow['kelas_pelajar']; ?></td>
        <td>
          <a href="adaftarpelajar_info.php?pid=<?php echo $readrow['id_pelajar']; ?>" class="btn btn-warning btn-xs" role="button">Maklumat</a>
          <a href="adaftarpelajar.php?edit=<?php echo $readrow['id_pelajar']; ?>" class="btn btn-success btn-xs" role="button"> Sunting </a>
          <a href="adaftarpelajar.php?delete=<?php echo $readrow['id_pelajar']; ?>" onclick="return confirm('Padam Data?');" class="btn btn-danger btn-xs" role="button">Padam</a>
        </td>
      </tr>
      <?php
      }
      ?>
 
    </table>
    </div>
  </div>

  <!--pagination bootstraps-->
  <div class="row" style="margin-left: -30px;">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <nav>
          <ul class="pagination">
          <?php
          try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare("SELECT * FROM tbl_daftarpelajar_fyp");
            $stmt->execute();
            $result = $stmt->fetchAll();
            $total_records = count($result);
          }
          catch(PDOException $e){
                echo "Error: " . $e->getMessage();
          }
          $total_pages = ceil($total_records / $per_page);
          ?>
          <?php if ($page==1) { ?>
            <li class="disabled"><span aria-hidden="true">«</span></li>
          <?php } else { ?>
            <li><a href="adaftarpelajar.php?page=<?php echo $page-1 ?>" aria-label="Kembali"><span aria-hidden="true">«</span></a></li>
          <?php
          }
          for ($i=1; $i<=$total_pages; $i++)
            if ($i == $page)
              echo "<li class=\"active\"><a href=\"adaftarpelajar.php?page=$i\">$i</a></li>";
            else
              echo "<li><a href=\"adaftarpelajar.php?page=$i\">$i</a></li>";
          ?>
          <?php if ($page==$total_pages) { ?>
            <li class="disabled"><span aria-hidden="true">»</span></li>
          <?php } else { ?>
            <li><a href="adaftarpelajar.php?page=<?php echo $page+1 ?>" aria-label="Previous"><span aria-hidden="true">»</span></a></li>
          <?php } ?>
        </ul>
      </nav>
    </div>

  </div>
</div>

   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>