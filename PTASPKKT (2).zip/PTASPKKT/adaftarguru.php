<?php
  include_once 'adaftarguru_crud.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : Daftar Guru</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
    body{
        background-image: url(bg.jpg);
      }

  .header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}

    </style>
</head>

<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  
<body>
  <!--navigation bar-->
  <?php include_once 'anav_bar.php'; ?>
 
<div class="container-fluid">
  <div class="row" style="height: 200px; margin-left: -100px;">
    <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
      <div class="page-header">
        <h2>Daftar Guru</h2>
      </div>
  
  <!--id guru-->
    <form action="adaftarguru.php" method="post" class="form-horizontal" enctype="multipart/form-data">

      <div class="form-group">
          <label for="idg" class="col-sm-3 control-label">ID</label>
          <div class="col-sm-6">
       <input name="gid" type="text" class="form-control" id="idguru" placeholder="ID Guru" value="<?php if(isset($_GET['edit'])) echo $editrow['id_guru']; ?>" required>

       </div>
        </div>

       <!--nama guru--> 
       <div class="form-group">
          <label for="ng" class="col-sm-3 control-label">Nama Penuh</label>
          <div class="col-sm-6">
       <input name="namaguru" type="text" class="form-control" id="nguru" placeholder="Nama Penuh" value="<?php if(isset($_GET['edit'])) echo $editrow['nama_guru']; ?>" required>

       </div>
        </div>
      

       <!--ic guru-->
       <div class="form-group">
          <label for="icg" class="col-sm-3 control-label">Kad Pengenalan</label>
          <div class="col-sm-6">
       <input name="icguru" type="text" class="form-control" id="icguru" placeholder="Kad Pengenalan" value="<?php if(isset($_GET['edit'])) echo $editrow['ic_guru']; ?>" required>
      
      </div>
        </div>

        <!--telefon guru-->
      <div class="form-group">
          <label for="telguru" class="col-sm-3 control-label">No. Telefon</label>
          <div class="col-sm-6">
      <input name="telefonguru" type="text" class="form-control" id="telguru" placeholder="No. Telefon" value="<?php if(isset($_GET['edit'])) echo $editrow['tel_guru']; ?>"required>
      </div>
        </div>

        <!--tingkatan guru -->
      <div class="form-group">
          <label for="tingguru" class="col-sm-3 control-label">Tingkatan</label>
          <div class="col-sm-6">

      <select name="tingkatanguru" class="form-control" id="tingguru" required>
        <option value="">Sila Pilih</option>
        <option value="1" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_guru']=="1") echo "selected"; ?>>1</option>
            <option value="2" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_guru']=="2") echo "selected"; ?>>2</option>
            <option value="3" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_guru']=="3") echo "selected"; ?>>3</option>
            <option value="4" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_guru']=="4") echo "selected"; ?>>4</option>
            <option value="5" <?php if(isset($_GET['edit'])) if($editrow['tingkatan_guru']=="5") echo "selected"; ?>>5</option>
      </select> 
      </div>
        </div>

         <!--kelas guru 1-->
      <div class="form-group">
          <label for="kelasgur1" class="col-sm-3 control-label">Kelas Diajar 1</label>
          <div class="col-sm-6">

      <select name="kelasguru1" class="form-control" id="tingpel" required>
        <option value="">Sila Pilih</option>
        <option value="Adil" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Adil") echo "selected"; ?>>Adil</option>
            <option value="Bestari" <?php if(isset($_GET['
            edit'])) if($editrow['kelas_guru1']=="Bestari") echo "selected"; ?>>Bestari</option>
            <option value="Cekal" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Cekal") echo "selected"; ?>>Cekal</option>
            <option value="Dinamik" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Dinamik") echo "selected"; ?>>Dinamik</option>
            <option value="Efisyen" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Efisyen") echo "selected"; ?>>Efisyen</option>
            <option value="Fikir" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Fikir") echo "selected"; ?>>Fikir</option>
            <option value="Gigih" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Gigih") echo "selected"; ?>>Gigih</option>
            <option value="Harmoni" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Harmoni") echo "selected"; ?>>Harmoni</option>
            <option value="Ikhlas" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Ikhlas") echo "selected"; ?>>Ikhlas</option>
            <option value="Jujur" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Jujur") echo "selected"; ?>>Jujur</option>
            <option value="Kreatif" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Kreatif") echo "selected"; ?>>Kreatif</option>
            <option value="Lestari" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Lestari") echo "selected"; ?>>Lestari</option>
            <option value="Maju" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Maju") echo "selected"; ?>>Maju</option>
            <option value="Nurani" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru1']=="Nurani") echo "selected"; ?>>Nurani</option>
      </select> 
      </div>
        </div>

        <!--kelas guru 2-->
      <div class="form-group">
          <label for="kelasgur2" class="col-sm-3 control-label">Kelas Diajar 2</label>
          <div class="col-sm-6">

      <select name="kelasguru2" class="form-control" id="kelguru2" required>
        <option value="">Sila Pilih</option>
        <option value="Tiada" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Tiada") echo "selected"; ?>>Tiada</option>
        <option value="Adil" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Adil") echo "selected"; ?>>Adil</option>
            <option value="Bestari" <?php if(isset($_GET['
            edit'])) if($editrow['kelas_guru2']=="Bestari") echo "selected"; ?>>Bestari</option>
            <option value="Cekal" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Cekal") echo "selected"; ?>>Cekal</option>
            <option value="Dinamik" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Dinamik") echo "selected"; ?>>Dinamik</option>
            <option value="Efisyen" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Efisyen") echo "selected"; ?>>Efisyen</option>
            <option value="Fikir" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Fikir") echo "selected"; ?>>Fikir</option>
            <option value="Gigih" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Gigih") echo "selected"; ?>>Gigih</option>
            <option value="Harmoni" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Harmoni") echo "selected"; ?>>Harmoni</option>
            <option value="Ikhlas" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Ikhlas") echo "selected"; ?>>Ikhlas</option>
            <option value="Jujur" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Jujur") echo "selected"; ?>>Jujur</option>
            <option value="Kreatif" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Kreatif") echo "selected"; ?>>Kreatif</option>
            <option value="Lestari" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Lestari") echo "selected"; ?>>Lestari</option>
            <option value="Maju" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Maju") echo "selected"; ?>>Maju</option>
            <option value="Nurani" <?php if(isset($_GET['edit'])) if($editrow['kelas_guru2']=="Nurani") echo "selected"; ?>>Nurani</option>
      </select> 


      <!--subjek guru 1-->
      </div>
        </div>
      <div class="form-group">
          <label for="subjguru1" class="col-sm-3 control-label">Subjek Diajar 1</label>
          <div class="col-sm-6">

      <select name="subjekguru1" class="form-control" id="subguru1" required>
        <option value="">Sila Pilih</option>
        <option value="Bahasa Melayu" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Bahasa Melayu") echo "selected"; ?>>Bahasa Melayu</option>
            <option value="Bahasa Inggeris" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Bahasa Inggeris") echo "selected"; ?>>Bahasa Inggeris</option>
            <option value="Sejarah" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Sejarah") echo "selected"; ?>>Sejarah</option>
            <option value="Geografi" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Geografi") echo "selected"; ?>>Geografi</option>
            <option value="Sains" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Sains") echo "selected"; ?>>Sains</option>
            <option value="Pendidikan Islam" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Pendidikan Islam") echo "selected"; ?>>Pendidikan Islam</option>
            <option value="Kimia" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Kimia") echo "selected"; ?>>Kimia</option>
            <option value="Biologi" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Biologi") echo "selected"; ?>>Biologi</option>
            <option value="Matematik" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Matematik") echo "selected"; ?>>Matematik</option>
            <option value="Matematik Tambahan" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Matematik Tambahan") echo "selected"; ?>>Matematik Tambahan</option>
            <option value="Reka Bentuk Teknologi" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Reka Bentuk Teknologi") echo "selected"; ?>>Reka Bentuk Teknologi</option>
            <option value="Tasawwur Islam" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Tasawwur Islam") echo "selected"; ?>>Tasawwur Islam</option>
            <option value="Ekonomi Asas" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Ekonomi Asas") echo "selected"; ?>>Ekonomi Asas</option>
            <option value="Prinsip Perakaunan" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Prinsip Perakaunan") echo "selected"; ?>>Prinsip Perakaunan</option>
            <option value="Pendidikan Jasmani" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Pendidikan Jasmani") echo "selected"; ?>>Pendidikan Jasmani</option>
            <option value="Pendidikan Seni Visual" <?php if(isset($_GET['edit'])) if($editrow['subj_guru1']=="Pendidikan Seni Visual") echo "selected"; ?>>Pendidikan Seni Visual</option>
      </select> 

      <!--subjek guru 2-->
      </div>
        </div>
      <div class="form-group">
          <label for="subjguru2" class="col-sm-3 control-label">Subjek Diajar 2</label>
          <div class="col-sm-6">

      <select name="subjekguru2" class="form-control" id="subguru2" required>
        <option value="">Sila Pilih</option>
        <option value="Tiada" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Tiada") echo "selected"; ?>>Tiada</option>
        <option value="Bahasa Melayu" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Bahasa Melayu") echo "selected"; ?>>Bahasa Melayu</option>
            <option value="Bahasa Inggeris" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Bahasa Inggeris") echo "selected"; ?>>Bahasa Inggeris</option>
            <option value="Sejarah" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Sejarah") echo "selected"; ?>>Sejarah</option>
            <option value="Geografi" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Geografi") echo "selected"; ?>>Geografi</option>
            <option value="Sains" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Sains") echo "selected"; ?>>Sains</option>
            <option value="Pendidikan Islam" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Pendidikan Islam") echo "selected"; ?>>Pendidikan Islam</option>
            <option value="Kimia" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Kimia") echo "selected"; ?>>Kimia</option>
            <option value="Biologi" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Biologi") echo "selected"; ?>>Biologi</option>
            <option value="Matematik" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Matematik") echo "selected"; ?>>Matematik</option>
            <option value="Matematik Tambahan" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Matematik Tambahan") echo "selected"; ?>>Matematik Tambahan</option>
            <option value="Reka Bentuk Teknologi" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Reka Bentuk Teknologi") echo "selected"; ?>>Reka Bentuk Teknologi</option>
            <option value="Tasawwur Islam" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Tasawwur Islam") echo "selected"; ?>>Tasawwur Islam</option>
            <option value="Ekonomi Asas" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Ekonomi Asas") echo "selected"; ?>>Ekonomi Asas</option>
            <option value="Prinsip Perakaunan" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Prinsip Perakaunan") echo "selected"; ?>>Prinsip Perakaunan</option>
            <option value="Pendidikan Jasmani" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Pendidikan Jasmani") echo "selected"; ?>>Pendidikan Jasmani</option>
            <option value="Pendidikan Seni Visual" <?php if(isset($_GET['edit'])) if($editrow['subj_guru2']=="Pendidikan Seni Visual") echo "selected"; ?>>Pendidikan Seni Visual</option>
      </select> 
      </div>
        </div>

        <!--password guru-->
      <div class="form-group">
          <label for="passguru" class="col-sm-3 control-label">Kata Laluan</label>
          <div class="col-sm-6">
      <input name="pass" type="text" class="form-control" id="passguru" placeholder="Kata Laluan" value="<?php if(isset($_GET['edit'])) echo $editrow['password_guru']; ?>"required>
      </div>
        </div>

        <!--re-password guru-->
      <div class="form-group">
          <label for="repass" class="col-sm-3 control-label">Ulangan Kata Laluan</label>
          <div class="col-sm-6">
      <input name="repassguru" type="text" class="form-control" id="repassgur" placeholder="Ulangan Kata Laluan" value="<?php if(isset($_GET['edit'])) echo $editrow['retype_pass_guru']; ?>"required>
      </div>
        </div>
        s
        <!--position guru-->
      <div class="form-group">
          <label for="posguru" class="col-sm-3 control-label">Jenis Pengguna</label>
          <div class="col-sm-6">

      <select name="pos" class="form-control" id="tingpel" required>
        <option value="">Sila Pilih</option>
        <option value="Admin" <?php if(isset($_GET['edit'])) if($editrow['position_guru']=="Admin") echo "selected"; ?>>Admin</option>
        <option value="Guru" <?php if(isset($_GET['edit'])) if($editrow['position_guru']=="Guru") echo "selected"; ?>>Guru</option>
      </select>
        </div>
        </div>
 <br><br>

<!--function button-->

        <div class="form-group">
          <div class="col-sm-offset-3 col-sm-9">

      <?php if (isset($_GET['edit'])) { ?>
      <input type="hidden" name="oldgid" value="<?php echo $editrow['id_guru']; ?>">
      <button class="btn btn-default" type="submit" name="update"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Kemaskini</button>
      <?php } else { ?>
      <button class="btn btn-default" type="submit" name="create"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Daftar</button>
      <?php } ?>
      <button class="btn btn-default" type="reset"><span class="glyphicon glyphicon-erase" aria-hidden="true"></span> Reset</button>
      

       </div>
      </div>
    </form>
     </div>
  </div>

  <div class="row" style="margin-left: -100px;">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-9 col-md-offset-2">
      <div class="page-header">
        <h2>Senarai Guru Berdaftar</h2>
      </div>
      <table class="table table-striped table-bordered">
    
      <tr>
          <th>ID Guru</th>
          <th>Nama</th>
          <th>Tingkatan</th>
          <th>Kelas Diajar 1</th>
          <th>Kelas Diajar 2</th>
          <th>Subjek Diajar 1</th>
          <th>Subjek Diajar 2</th>
          <th>Tindakan</th>
          
      </tr>

      <?php
      // Read
      $per_page = 5; //record per page
      if (isset($_GET["page"]))
        $page = $_GET["page"];
      else
        $page = 1;
      $start_from = ($page-1) * $per_page;
      try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $conn->prepare("SELECT * FROM tbl_daftarguru_fyp");
           $stmt = $conn->prepare("select * from tbl_daftarguru_fyp LIMIT $start_from, $per_page");
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $readrow) {
      ?>   
      <tr>
        <td><?php echo $readrow['id_guru']; ?></td>
        <td><?php echo $readrow['nama_guru']; ?></td>
        <td><?php echo $readrow['tingkatan_guru']; ?></td>
        <td><?php echo $readrow['kelas_guru1']; ?></td>
        <td><?php echo $readrow['kelas_guru2']; ?></td>
        <td><?php echo $readrow['subj_guru1']; ?></td>
        <td><?php echo $readrow['subj_guru2']; ?></td>
        
        <td>
          <a href="asenaraiguru.php?pid=<?php echo $readrow['id_guru']; ?>" class="btn btn-warning btn-xs" role="button">Maklumat</a>
          <a href="adaftarguru.php?edit=<?php echo $readrow['id_guru']; ?>" class="btn btn-success btn-xs" role="button"> Sunting</a>
          <a href="adaftarguru.php?delete=<?php echo $readrow['id_guru']; ?>" onclick="return confirm('Padam Data?');" class="btn btn-danger btn-xs" role="button">Padam</a>
        </td>
      </tr>
      <?php
      }
      ?>
 
    </table>
    </div>
  </div>

  <!--pagination bootstraps-->
  <div class="row" style="margin-left: -100px;">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <nav>
          <ul class="pagination">
          <?php
          try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $conn->prepare("SELECT * FROM tbl_daftarguru_fyp");
            $stmt->execute();
            $result = $stmt->fetchAll();
            $total_records = count($result);
          }
          catch(PDOException $e){
                echo "Error: " . $e->getMessage();
          }
          $total_pages = ceil($total_records / $per_page);
          ?>
          <?php if ($page==1) { ?>
            <li class="disabled"><span aria-hidden="true">«</span></li>
          <?php } else { ?>
            <li><a href="adaftarguru.php?page=<?php echo $page-1 ?>" aria-label="Kembali"><span aria-hidden="true">«</span></a></li>
          <?php
          }
          for ($i=1; $i<=$total_pages; $i++)
            if ($i == $page)
              echo "<li class=\"active\"><a href=\"adaftarguru.php?page=$i\">$i</a></li>";
            else
              echo "<li><a href=\"adaftarguru.php?page=$i\">$i</a></li>";
          ?>
          <?php if ($page==$total_pages) { ?>
            <li class="disabled"><span aria-hidden="true">»</span></li>
          <?php } else { ?>
            <li><a href="adaftarguru.php?page=<?php echo $page+1 ?>" aria-label="Previous"><span aria-hidden="true">»</span></a></li>
          <?php } ?>
        </ul>
      </nav>
    </div>

  </div>
</div>

   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>