<?php
 
include_once 'database.php';

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//Create
if (isset($_POST['create'])) {
 
  try {
 
      $stmt = $conn->prepare("INSERT INTO tbl_daftarpelajar_fyp(id_pelajar, ic_pelajar,
        nama_pelajar, tingkatan_pelajar, kelas_pelajar, tel_pelajar, tel_ibubapa) VALUES(:pid, :icpelajar, :namapelajar, :tingkatanpelajar, :kelaspelajar,
        :telefonpelajar, :telefonibubapa)");


      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $stmt->bindParam(':icpelajar', $icpelajar, PDO::PARAM_STR);
      $stmt->bindParam(':namapelajar', $namapelajar, PDO::PARAM_STR);
      $stmt->bindParam(':tingkatanpelajar', $tingkatanpelajar, PDO::PARAM_INT);
      $stmt->bindParam(':kelaspelajar', $kelaspelajar, PDO::PARAM_STR);
      $stmt->bindParam(':telefonpelajar', $telefonpelajar, PDO::PARAM_STR);
      $stmt->bindParam(':telefonibubapa', $telefonibubapa, PDO::PARAM_STR);
      

    $pid = $_POST['pid'];  
    $icpelajar = $_POST['icpelajar'];
    $namapelajar = $_POST['namapelajar'];
    $tingkatanpelajar = $_POST['tingkatanpelajar'];
    $kelaspelajar =  $_POST['kelaspelajar'];
    $telefonpelajar = $_POST['telefonpelajar'];
    $telefonibubapa = $_POST['telefonibubapa'];
    
     
    $stmt->execute();
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Update
if (isset($_POST['update'])) {
 
  try {
 
      $stmt = $conn->prepare("UPDATE tbl_daftarpelajar_fyp SET id_pelajar = :pid, ic_pelajar = :icpelajar,
        nama_pelajar = :namapelajar, tingkatan_pelajar = :tingkatanpelajar, kelas_pelajar = :kelaspelajar,
        tel_pelajar = :telefonpelajar, tel_ibubapa = :telefonibubapa 
        WHERE id_pelajar = :oldpid");

      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $stmt->bindParam(':icpelajar', $icpelajar, PDO::PARAM_STR);
      $stmt->bindParam(':namapelajar', $namapelajar, PDO::PARAM_STR);
      $stmt->bindParam(':tingkatanpelajar', $tingkatanpelajar, PDO::PARAM_INT);
      $stmt->bindParam(':kelaspelajar', $kelaspelajar, PDO::PARAM_STR);
      $stmt->bindParam(':telefonpelajar', $telefonpelajar, PDO::PARAM_STR);
      $stmt->bindParam(':telefonibubapa', $telefonibubapa, PDO::PARAM_STR);
      $stmt->bindParam(':oldpid', $oldpid, PDO::PARAM_STR);
       
    $pid = $_POST['pid'];
    $icpelajar = $_POST['icpelajar'];
    $namapelajar = $_POST['namapelajar'];
    $tingkatanpelajar = $_POST['tingkatanpelajar'];
    $kelaspelajar =  $_POST['kelaspelajar'];
    $telefonpelajar = $_POST['telefonpelajar'];
    $telefonibubapa = $_POST['telefonibubapa'];
    $oldpid = $_POST['oldpid'];
     
    $stmt->execute();
 
    header("Location: adaftarpelajar.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Delete
if (isset($_GET['delete'])) {
 
  try {
 
      $stmt = $conn->prepare("DELETE FROM tbl_daftarpelajar_fyp WHERE id_pelajar = :pid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
       
    $pid = $_GET['delete'];
     
    $stmt->execute();
 
    header("Location: adaftarpelajar.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Edit
if (isset($_GET['edit'])) {
 
  try {
 
      $stmt = $conn->prepare("SELECT * FROM tbl_daftarpelajar_fyp WHERE id_pelajar = :pid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
       
    $pid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
  $conn = null;
?>