<?php
include once 'database.php';
session_start();

	$gid = $_SESSION['id_guru'];

	$stmt = $conn->prepare("SELECT * FROM tbl_daftarguru_fyp WHERE id_guru = '$gid'");

	$stmt->execute();

	$readrow = $stmt->fetch(PDO::FETCH_ASSOC);


	$gid = $readrow['id_guru'];
	$pos = $readrow['position_guru'];
	$namaguru = $readrow['nama_guru'];


	$_SESSION['namaguru'] = $namaguru;


		//welcome message
		$_SESSION['success'] = "Anda telah mengelog masuk sistem."


		if ($gid =='') {
			# code...
			header("location:loginpage.php?login");
		}
		else{
			header("");
		}




?>