<?php
  include_once 'database.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : Maklumat Guru</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
      body{
        background-image: url(bg.jpg);
      }

      .header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}

    </style>
</head>

<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  
<body>
  <!--navigation bar-->
  <?php include_once 'anav_bar.php'; ?>

    <?php
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM tbl_daftarguru_fyp WHERE id_guru = :gid");
      $stmt->bindParam(':gid', $gid, PDO::PARAM_STR);
      $gid = $_GET['gid'];
      $stmt->execute();
      $readrow = $stmt->fetch(PDO::FETCH_ASSOC);
      }
    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
    ?>

    <div class="container-fluid">
  <div class="row">
    <div class="col-xs-12 col-sm-5 col-sm-offset-1 col-md-4 col-md-offset-2 well well-sm text-center">
      <?php if ($readrow['gambar_guru'] == "" ) {
        echo "No image";
      }
      else { ?>
      <img src="gambar/<?php echo $readrow['gambar_guru'] ?>" class="img-responsive">
      <?php } ?>
    </div>
    <div class="col-xs-12 col-sm-5 col-md-4">
      <div class="panel panel-default">
      <div class="panel-heading"><strong>MAKLUMAT GURU</strong></div>
      <div class="panel-body">
          Berikut adalah maklumat guru yang telah daftar:
      </div>
      <table class="table">
        <tr>
          <td class="col-xs-4 col-sm-4 col-md-4"><strong>ID Guru</strong></td>
          <td><?php echo $readrow['id_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>Nama Penuh</strong></td>
          <td><?php echo $readrow['nama_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>Kad Pengenalan</strong></td>
          <td><?php echo $readrow['ic_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>No. Telefon</strong></td>
          <td><?php echo $readrow['tel_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>Tingkatan Diajar</strong></td>
          <td><?php echo $readrow['tingkatan_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>Kelas Diajar 1</strong></td>
          <td><?php echo $readrow['kelas_guru1'] ?></td>
        </tr>
        <tr>
          <td><strong>Kelas Diajar 2</strong></td>
          <td><?php echo $readrow['kelas_guru2'] ?></td>
        </tr>
        <tr>
          <td><strong>Subjek Diajar 1</strong></td>
          <td><?php echo $readrow['subj_guru1'] ?></td>
        </tr>
        <tr>
          <td><strong>Subjek Diajar 2</strong></td>
          <td><?php echo $readrow['subj_guru2'] ?></td>
        </tr>
        <tr>
          <td><strong>Kata Laluan</strong></td>
          <td><?php echo $readrow['password_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>Ulangan Kata Laluan</strong></td>
          <td><?php echo $readrow['retype_pass_guru'] ?></td>
        </tr>
        <tr>
          <td><strong>Jenis Pengguna</strong></td>
          <td><?php echo $readrow['position_guru'] ?></td>
        </tr>
      </table>
      </div>
    </div>
  </div>
</div>
 
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    
</body>
</html>