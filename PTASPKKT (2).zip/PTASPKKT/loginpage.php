<?php
include_once 'database.php';
error_reporting(0);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : Log In</title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  
</head>
<body style="background-color:#f1f1f1;">
  <center>
    <br>
    <br>
    <b><font face="Georgia" size="25" style="font-weight: bold;">SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</font></h></b>
    <br>
    <br>
</center>
  

     
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
  
 
   <br>
  <h3><center><b><i></i></b></center></h3>

<?php if($_GET['login']=="failed"){ ?>
  <h5><center><b><i><font color="red">Maaf. Kata laluan salah. Sila masukkan kata laluan semula!</font></i></b></center></h5>
<?php } ?>

  <form action="login.php" method="post" class="form-horizontal">

    <h3><center><font style="font-weight: bold;"> Log Masuk </font></center></h3>

    <br>
    <br>
    <div class="form-group">
      <div class="col-sm-5 col-sm-offset-4 control-label">
        <input name="gid" type="text" class="form-control" placeholder="ID Pengguna" required />
      </div>
        </div>
    <div class="form-group">
      <div class="col-sm-5 col-sm-offset-4 control-label">
       <input name="pass" type="password" class="form-control" placeholder="Kata Laluan"required />
      </div>
    </div>

    <div class="form-group">
          <label for="position" class="col-sm-1 col-sm-offset-4 control-label"></label>
          <div></div>
          <div class="col-sm-5 col-sm-offset-4">
         <select name="pos" class="form-control" id="position" required>
            <option value="">Jenis Pengguna</option>
            <option value="Admin">Admin</option>
            <option value="Guru"required >Guru</option>
          </select>
        </div>
        </div>     

    <div class="form-group">
          <div class="col-sm-3 col-sm-offset-5">
      <center><button class="btn btn-default" type="submit"  style="background-color: #6FD53F" name="submit" ><span  aria-hidden="true"></span> Log Masuk</button>
      </div>
    </div>
  </form>
</font>
<br>
<br>

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

</body>
</html>