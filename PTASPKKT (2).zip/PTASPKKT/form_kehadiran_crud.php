<?php
 
include_once 'database.php';

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//Create
if (isset($_POST['create'])) {
 
  try {
 
      $stmt = $conn->prepare("INSERT INTO tbl_pelajarmasuk_fyp(id_pelajar, nama_pelajar, tingkatan_pelajar, kelas_pelajar, subj_pelajar, nama_guru) VALUES(:pid, :namapelajar, :tingkatanpelajar, :kelaspelajar, :subjekpelajar, :namaguru)");


      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $stmt->bindParam(':namapelajar', $namapelajar, PDO::PARAM_STR);
      $stmt->bindParam(':tingkatanpelajar', $tingkatanpelajar, PDO::PARAM_INT);
      $stmt->bindParam(':kelaspelajar', $kelaspelajar, PDO::PARAM_STR);
      $stmt->bindParam(':subjekpelajar', $subjekpelajar, PDO::PARAM_STR);
      $stmt->bindParam(':namaguru', $namaguru, PDO::PARAM_STR);
      

    $pid = $_POST['pid'];  
    $namapelajar = $_POST['namapelajar'];
    $tingkatanpelajar = $_POST['tingkatanpelajar'];
    $kelaspelajar =  $_POST['kelaspelajar'];
    $subjekpelajar = $_POST['subjekpelajar'];
    $namaguru = $_POST['namaguru'];

    $stmt->execute();
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Update
if (isset($_POST['update'])) {
 
  try {
 
      $stmt = $conn->prepare("UPDATE tbl_pelajarmasuk_fyp SET id_pelajar = :pid, nama_pelajar = :namapelajar, tingkatan_pelajar = :tingkatanpelajar, kelas_pelajar = :kelaspelajar,
        subj_pelajar = :subjekpelajar, nama_guru = :namaguru WHERE id_pelajar = :oldpid");

      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
      $stmt->bindParam(':namapelajar', $namapelajar, PDO::PARAM_STR);
      $stmt->bindParam(':tingkatanpelajar', $tingkatanpelajar, PDO::PARAM_INT);
      $stmt->bindParam(':kelaspelajar', $kelaspelajar, PDO::PARAM_STR);
      $stmt->bindParam(':subjekpelajar', $subjekpelajar, PDO::PARAM_STR);
      $stmt->bindParam(':namaguru', $namaguru, PDO::PARAM_STR);
      $stmt->bindParam(':oldpid', $oldpid, PDO::PARAM_STR);
       
    $pid = $_POST['pid'];
    $namapelajar = $_POST['namapelajar'];
    $tingkatanpelajar = $_POST['tingkatanpelajar'];
    $kelaspelajar =  $_POST['kelaspelajar'];
    $subjekpelajar = $_POST['subjekpelajar'];
    $namaguru = $_POST['namaguru'];
    $oldpid = $_POST['oldpid'];
     
    $stmt->execute();
 
    header("Location: form_kehadiran.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Delete
if (isset($_GET['delete'])) {
 
  try {
 
      $stmt = $conn->prepare("DELETE FROM tbl_pelajarmasuk_fyp WHERE id_pelajar = :pid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
       
    $pid = $_GET['delete'];
     
    $stmt->execute();
 
    header("Location: form_kehadiran.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Edit
if (isset($_GET['edit'])) {
 
  try {
 
      $stmt = $conn->prepare("SELECT * FROM tbl_pelajarmasuk_fyp WHERE id_pelajar = :pid");
     
      $stmt->bindParam(':pid', $pid, PDO::PARAM_STR);
       
    $pid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
  $conn = null;
?>