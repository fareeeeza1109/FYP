<?php
  include_once 'adaftarpelajar_crud.php';
?>
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>SPKKT : Rekod Kedatangan </title>
  <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

 <style type="text/css">

  input{
    width: 70%;
  }

body {
    background-image: url("bg.jpg");
}

.header {
  background-color: #f1f1f1;
  padding: 30px;
  text-align: center;
  font-family: "Times New Roman", Times, serif;
  font-weight: bold; 
}

</style>
    
</head>
<div class="header">
  <h2>SISTEM PENGURUSAN KEHADIRAN KELAS DALAM TALIAN</h2>


</div>  
<body>
   
  <?php include_once 'anav_bar.php'; ?>
 
 
  <div class="row">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <div class="page-header">
        <h2>Senarai Rekod</h2>
      </div>
       <table>
    <form method="post">
      <tr>
      <td>Carian</td>
      </tr>
      <tr>
       <td><input id="keyword" name="keyword" class="form-control" type="text" placeholder="Carian.." style="width: 500px;" required></td>
      </tr>
    </form>
    </table>

    <br>
      <table class="table table-striped table-bordered">
        <tr>
        <th>Tingkatan</th>
        <th>Kelas</th>
        <th>Tarikh</th>
        <th></th>
        </tr>

      <?php
      
      $per_page = 8;
      if(isset($_GET['page'])){
        $page = $_GET['page'];
      }
      else{
          $page = 1;
      }
      $start_from = ($page - 1) * $per_page;
      if(isset($_POST['keyword'])){
        $keyword = $_POST['keyword'];
      }
      else if(isset($_GET['keyword'])){
        $keyword = $_GET['keyword'];
      }
 
      try {

        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        if(isset($keyword)){
        $stmt = $conn->prepare("select * from tbl_senaraikehadiran_fyp where tingkatan_pelajar like '%$keyword%' or kelas_pelajar like '%$keyword%' or tarikh_kehadiran like '%$keyword%' LIMIT $start_from, $per_page");}
        else{
          $stmt = $conn->prepare("SELECT * FROM tbl_senaraikehadiran_fyp LIMIT :start_from, :per_page");
          $stmt->bindParam(':start_from', $start_from, PDO::PARAM_INT);
          $stmt->bindParam(':per_page', $per_page, PDO::PARAM_INT);
        }
        $stmt->execute();
        $result = $stmt->fetchAll();
      }
      catch(PDOException $e){
            echo "Error: " . $e->getMessage();
      }
      foreach($result as $readrow) {
      ?> 
      <tr>
        <td><?php echo $readrow['tingkatan_pelajar']; ?></td>
        <td><?php echo $readrow['kelas_pelajar']; ?></td>
        <td><?php echo $readrow['tarikh_kehadiran']; ?></td>
        <td>
          <a href="arekodkedatangan_info.php?gid=<?php echo $readrow['kelas_pelajar']; ?>" class="btn btn-warning btn-xs" role="button">Maklumat</a>
          
        </td>
      </tr>
      <?php }  ?>
 
      </table>
    </div>
  </div>

  <div class="row">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
      <nav>
          <ul class="pagination">
          <?php
          try {
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            if(isset($keyword)){
            $stmt = $conn->prepare("select * from tbl_senaraikehadiran_fyp where tingkatan_pelajar like '%$keyword%' or kelas_pelajar like '%$keyword%' or tarikh_kehadiran like '%$keyword%'");}
            else{
              $stmt = $conn->prepare('SELECT * FROM tbl_senaraikehadiran_fyp');
            }
            $stmt->execute();
            $result = $stmt->fetchAll();
            $total_records = count($result);
          }
          catch(PDOException $e){
                echo "Error: " . $e->getMessage();
          }
          $total_pages = ceil($total_records / $per_page);

          if ($page == 1){ ?>
            <li class="disabled"><span aria-hidden="true">«</span></li>
          <?php } else{ 
            if(isset($keyword)){?>
            <li><a href="arekodkedatangan.php?page=<?php echo $page - 1;?>&keyword=<?php echo $keyword;?>" aria-label="Kembali"><span aria-hidden="true">«</span></a></li>
            <?php } else{ ?>
            <li><a href="arekodkedatangan.php?page=<?php echo $page - 1;?>" aria-label="Kembali"><span aria-hidden="true">«</span></a></li>
            <?php }?>
          <?php }
          for($i = 1; $i <= $total_pages; $i++){
            if($i == $page){
              if(isset($keyword)){
                echo '<li class="active"><a href="arekodkedatangan.php?page=' . $i . '&keyword=' . $keyword . '">' . $i . '</a></li>';
              } else{ 
                echo '<li class="active"><a href="arekodkedatangan.php?page=' . $i . '">' . $i . '</a></li>';
              }
            }
            else{
              if(isset($keyword)){
                echo '<li><a href="arekodkedatangan.php?page=' . $i . '&keyword=' . $keyword . '">' . $i . '</a></li>';
              }
              else{
                echo '<li><a href="arekodkedatangan.php?page=' . $i . '">' . $i . '</a></li>';
              }
            }
          }
          if($total_pages == $page){ ?>
            <li class="disabled"><span aria-hidden="true">»</span></li>
          <?php } else{ 
            if(isset($keyword)){?>
            <li><a href="arekodkedatangan.php?page=<?php echo $page + 1;?>&keyword=<?php echo $keyword;?>" aria-label="Seterusnya"><span aria-hidden="true">»</span></a></li>
            <?php } else{ ?>
            <li><a href="arekodkedatangan.php?page=<?php echo $page + 1;?>" aria-label="Seterusnya"><span aria-hidden="true">»</span></a></li>
            <?php } 
          } ?>
        </ul>
      </nav>
    </div> 
</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
 
</body>
</html>